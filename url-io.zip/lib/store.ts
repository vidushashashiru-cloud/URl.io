import { kv } from "@vercel/kv";
import { customAlphabet } from "nanoid";

// Lowercase letters + digits, no ambiguous characters (0/O, 1/l/I removed)
const nanoid = customAlphabet("23456789abcdefghjkmnpqrstuvwxyz", 7);

const RESERVED = new Set([
  "api", "s", "admin", "login", "logout", "sitemap.xml", "robots.txt",
  "favicon.ico", "about", "terms", "privacy", "contact", "_next"
]);

export type LinkRecord = {
  slug: string;
  url: string;
  createdAt: number;
  clicks: number;
};

function linkKey(slug: string) {
  return `link:${slug}`;
}

function isValidSlug(slug: string) {
  return /^[a-zA-Z0-9_-]{3,32}$/.test(slug) && !RESERVED.has(slug.toLowerCase());
}

function isValidUrl(url: string) {
  try {
    const parsed = new URL(url);
    return parsed.protocol === "http:" || parsed.protocol === "https:";
  } catch {
    return false;
  }
}

export async function createLink(
  longUrl: string,
  customSlug?: string
): Promise<{ ok: true; record: LinkRecord } | { ok: false; error: string }> {
  if (!isValidUrl(longUrl)) {
    return { ok: false, error: "Enter a valid http:// or https:// URL." };
  }

  let slug = customSlug?.trim();

  if (slug) {
    if (!isValidSlug(slug)) {
      return {
        ok: false,
        error:
          "Custom alias must be 3-32 characters: letters, numbers, - or _ only."
      };
    }
    const existing = await kv.get<LinkRecord>(linkKey(slug));
    if (existing) {
      return { ok: false, error: "That alias is already taken." };
    }
  } else {
    // Generate a unique random slug, retrying on the rare collision.
    for (let attempt = 0; attempt < 5; attempt++) {
      const candidate = nanoid();
      const existing = await kv.get<LinkRecord>(linkKey(candidate));
      if (!existing) {
        slug = candidate;
        break;
      }
    }
    if (!slug) {
      return { ok: false, error: "Could not generate a link. Try again." };
    }
  }

  const record: LinkRecord = {
    slug,
    url: longUrl,
    createdAt: Date.now(),
    clicks: 0
  };

  await kv.set(linkKey(slug), record);
  return { ok: true, record };
}

export async function getLink(slug: string): Promise<LinkRecord | null> {
  if (!isValidSlug(slug)) return null;
  const record = await kv.get<LinkRecord>(linkKey(slug));
  return record ?? null;
}

export async function registerClick(slug: string): Promise<void> {
  const key = linkKey(slug);
  const record = await kv.get<LinkRecord>(key);
  if (!record) return;
  record.clicks += 1;
  await kv.set(key, record);
}
