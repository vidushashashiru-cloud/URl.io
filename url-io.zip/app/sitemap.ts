import type { MetadataRoute } from "next";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://your-domain.vercel.app";

export default function sitemap(): MetadataRoute.Sitemap {
  return [
    { url: siteUrl, lastModified: new Date(), priority: 1 },
    { url: `${siteUrl}/terms`, lastModified: new Date(), priority: 0.3 },
    { url: `${siteUrl}/privacy`, lastModified: new Date(), priority: 0.3 }
  ];
}
