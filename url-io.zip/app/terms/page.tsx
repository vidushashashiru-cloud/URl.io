export const metadata = { title: "Terms of Service" };

export default function TermsPage() {
  return (
    <div className="wrap">
      <a href="/" className="wordmark">
        url<b>.io</b>
      </a>
      <h1>Terms of Service</h1>
      <p className="lede">
        By using URL.IO you agree not to shorten links pointing to illegal,
        abusive, or malicious content. We may disable any link that violates
        this policy without notice. The service is provided as-is, with no
        guarantee of uptime or permanence — don't rely on it for links you
        can't afford to lose.
      </p>
    </div>
  );
}
