import ShortenerForm from "./shortener-form";

export default function HomePage() {
  return (
    <div className="wrap">
      <header className="site">
        <a href="/" className="wordmark">
          url<b>.io</b>
        </a>
        <span className="tagline">free link shortener</span>
      </header>

      <h1>Shorten a link in one click</h1>
      <p className="lede">
        Paste a long URL below to get a short, shareable link. Pick your own
        alias or let us generate one. No account needed.
      </p>

      <ShortenerForm />

      <section className="features" aria-label="Why use URL.IO">
        <div className="feature">
          <h3>Custom aliases</h3>
          <p>Choose a memorable slug instead of a random string of letters.</p>
        </div>
        <div className="feature">
          <h3>Click tracking</h3>
          <p>Every short link quietly counts how many times it's opened.</p>
        </div>
        <div className="feature">
          <h3>Fast redirects</h3>
          <p>Links resolve in under a second, backed by edge storage.</p>
        </div>
        <div className="feature">
          <h3>No sign-up</h3>
          <p>Generate and share links immediately — nothing to register.</p>
        </div>
      </section>

      <footer className="site">
        <span>© {new Date().getFullYear()} URL.IO</span>
        <span>
          <a href="/terms">Terms</a> · <a href="/privacy">Privacy</a>
        </span>
      </footer>
    </div>
  );
}
