import { NextRequest, NextResponse } from "next/server";
import { createLink } from "@/lib/store";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://your-domain.vercel.app";

export async function POST(req: NextRequest) {
  let body: { url?: string; alias?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const { url, alias } = body;
  if (!url || typeof url !== "string") {
    return NextResponse.json({ error: "A URL is required." }, { status: 400 });
  }

  const result = await createLink(url, alias);
  if (!result.ok) {
    return NextResponse.json({ error: result.error }, { status: 400 });
  }

  return NextResponse.json({
    slug: result.record.slug,
    shortUrl: `${siteUrl.replace(/\/$/, "")}/${result.record.slug}`
  });
}
