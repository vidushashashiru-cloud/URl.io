# URL.IO — custom link shortener

A self-hosted short link generator built with Next.js, deployable to Vercel
for free. Features:

- Custom aliases or auto-generated short codes
- Click counting per link
- An interstitial "redirect" page between the short link and the
  destination, with a Google AdSense slot, so clicks can earn ad revenue
  before forwarding to the original URL
- SEO basics: metadata, Open Graph tags, `sitemap.xml`, `robots.txt`
- No AI branding or watermark anywhere in the UI or generated links

---

## සරල සාරාංශය (Sinhala quick summary)

මේක ඔයාගේම SHORT LINK GENERATOR website එකක් — ජනනය කරන සෑම LINK එකකටම
CLICK කළාම මුලින්ම ඔයාගේම REDIRECT PAGE එකක් පෙන්වනවා (ඒකේ ADSENSE AD එකක්
තියෙනවා), ටික SECONDS ගානකින් ORIGINAL LINK එකට REDIRECT වෙනවා. SEO META TAGS,
sitemap, robots.txt සියල්ල දාලා තියෙනවා. AI සම්බන්ධ කිසිම TEXT/LOGO එකක් නෑ.

**පියවර:**
1. මේ FOLDER එක GITHUB REPO එකකට PUSH කරන්න.
2. [vercel.com](https://vercel.com) එකේ "New Project" → ඔයාගේ REPO එක IMPORT
   කරන්න.
3. Vercel → **Storage** tab → **Create Database** → **KV** තෝරලා, මේ
   PROJECT එකට CONNECT කරන්න (env vars auto-fill වෙනවා).
4. **Settings → Environment Variables** එකේ `NEXT_PUBLIC_SITE_URL` ඔයාගේ
   DOMAIN එකට SET කරන්න.
5. [Google AdSense](https://adsense.google.com) එකෙන් APPROVAL ගත්තට පස්සේ
   `NEXT_PUBLIC_ADSENSE_CLIENT` සහ `NEXT_PUBLIC_ADSENSE_SLOT_INTERSTITIAL`
   SET කරන්න.
6. Redeploy කරන්න — DONE.

**වැදගත්:** `url.io` කියන DOMAIN එක දැනටමත් වෙන කෙනෙකුට EXIST වෙනවා, ඒ නිසා
ඔයාට EXACT ඒ DOMAIN එක ගන්න බැරි වෙන්න පුළුවන් — වෙන .com / .link / .lk
DOMAIN එකක් ගන්න වෙයි. "URL.IO" කියන නම BRAND NAME එක විදියට code එකේ
COMMENT/TITLE විදියට පාවිච්චි කරලා තියෙනවා.

---

## Local development

```bash
npm install
cp .env.example .env.local   # fill in KV_* vars from a Vercel KV instance
npm run dev
```

## Deploy to Vercel (step by step)

### 1. Push to GitHub
```bash
cd url-io
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/url-io.git
git push -u origin main
```

### 2. Import into Vercel
- Go to vercel.com → **Add New → Project**
- Select your `url-io` GitHub repo → Deploy (framework preset: Next.js,
  auto-detected)

### 3. Add storage (Vercel KV)
Links need somewhere to live — serverless functions can't use a local file.
- In your Vercel project → **Storage** tab → **Create Database** → **KV**
- Connect it to this project. Vercel automatically adds `KV_URL`,
  `KV_REST_API_URL`, `KV_REST_API_TOKEN` to your environment variables.

### 4. Set your site URL
- **Settings → Environment Variables** → add `NEXT_PUBLIC_SITE_URL` with
  your real deployed domain (e.g. `https://short.yourdomain.com`), no
  trailing slash.
- Redeploy after adding/changing any environment variable.

### 5. Connect Google AdSense
- Apply at adsense.google.com with your deployed domain (AdSense requires a
  live site with real content before it approves an account — your privacy
  and terms pages already exist for this).
- Once approved, create an ad unit and set:
  - `NEXT_PUBLIC_ADSENSE_CLIENT` → your publisher ID (`ca-pub-...`)
  - `NEXT_PUBLIC_ADSENSE_SLOT_INTERSTITIAL` → the ad unit's slot ID
- The interstitial redirect page will then render a real ad instead of the
  placeholder box.

### 6. Custom domain (optional)
- **Settings → Domains** → add your own domain, point its DNS at Vercel as
  instructed, then update `NEXT_PUBLIC_SITE_URL` to match.

---

## How it works

- `app/page.tsx` + `app/shortener-form.tsx` — the home page form that posts
  to `/api/shorten`
- `app/api/shorten/route.ts` — validates the URL/alias and saves it via
  `lib/store.ts`
- `lib/store.ts` — all Vercel KV reads/writes (create link, look up by slug,
  count clicks)
- `app/[slug]/page.tsx` + `redirect-client.tsx` — the interstitial page
  shown when someone opens a short link: shows an ad slot and a 5-second
  countdown, then forwards to the real URL (visitors can also click "Skip
  waiting" to go immediately)
- `app/sitemap.ts`, `app/robots.ts` — SEO files Next.js serves automatically
  at `/sitemap.xml` and `/robots.txt`

## Notes

- Short codes avoid ambiguous characters (no `0/O`, `1/l/I`) so they're easy
  to read aloud or retype.
- Reserved words (`api`, `admin`, `terms`, etc.) can't be used as custom
  aliases so they don't collide with site pages.
- There is no login/admin dashboard in this version — anyone with the
  Vercel KV dashboard can see raw link data. Ask if you'd like a simple
  password-protected admin page added to list/delete links.
